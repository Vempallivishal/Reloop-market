# ReLoop Market – CampusSwap

A beginner-friendly frontend project made with HTML, CSS and vanilla JavaScript.

## Run the project
1. Download and extract `ReLoop_CampusSwap_Website.zip`.
2. Open the `campusswap_website` folder.
3. Double-click `index.html` to open it in Chrome, Edge or Firefox.
4. No installation or server is required.

## Demo login
- Name: Rahul Sharma
- Email: rahul@campus.edu
- Branch: Computer Science
- Demo OTP: `246810`

You can also use an email ending in `@univ.ac.in`.

## Files
- `index.html` – page structure and sections
- `style.css` – colors, layout and responsive design
- `script.js` – UI wiring: views, rendering, chat, listing flow
- `js/validators.js` – input validation and schema checks (forms and stored data)
- `js/storage.js` – safe localStorage wrapper (try/catch, schema validation, quota errors)
- `js/auth.js` – simulated sign-in: OTP expiry (5 min), 5-attempt limit, 24-hour session
- `js/search.js` – relevance-ranked, typo-tolerant search; price suggestions; similar items
- `js/api.js` – async data-access layer with pagination (the seam for a future backend)
- `tests.html` + `js/tests.js` – 20 dependency-free tests; open `tests.html` in a browser

## Important project notes
- This is a frontend demonstration. Email verification and OTP are simulated in JavaScript; they do not contact a college server or send a real OTP.
- Chat is simulated and stored in this browser only.
- Product listings, donation posts, chat messages and demo user details are stored using browser localStorage.
- The campus map is an illustrative mock map, not a live GPS map.
- For real deployment, add a secure backend, database, real email/OTP verification, image storage and server-side authorization. Never rely on client-side email checks for real authentication.

## Run the tests
Open `tests.html` in a browser. (With Node installed, the same test file also runs from the command line.)

## Design decisions
- The brief limits this project to HTML, CSS and JavaScript, so there is no server or database. Scripts are plain
  files (not ES modules) so the site still works when opened by double-clicking index.html.
- Anything that needs a server is deliberately out of scope here: real OTP delivery, real authentication,
  server-side authorization and a database. `js/api.js` is where those would plug in.
- Client-side checks (session expiry, schema validation of stored data) raise the bar but cannot stop a determined user.

## Reset demo data
Clear this website's localStorage in browser developer tools, or open the site in a private/incognito window.
