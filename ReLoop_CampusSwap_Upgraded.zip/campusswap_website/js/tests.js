/* Dependency-free tests. Open tests.html in a browser (or run in Node) to see results. */
(function (root) {
  const RL = root.ReLoop;
  const pending = [], results = [];
  const test = (name, fn) => pending.push(
    Promise.resolve().then(fn).then(() => results.push({ name, ok: true }), (e) => results.push({ name, ok: false, msg: e.message })));
  const eq = (a, b) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`); };
  const ok = (c, m) => { if (!c) throw new Error(m || "assertion failed"); };
  const V = RL.validators, A = RL.auth, S = RL.search;
  const item = (id, title, category, price, extra = {}) => ({ id, title, category, price, ...extra });

  test("email: accepts campus domains", () => { ok(V.isCampusEmail("rahul@campus.edu")); ok(V.isCampusEmail("A.B@univ.ac.in")); });
  test("email: rejects look-alike domains", () => {
    ["a@campus.edu.evil.com", "@campus.edu", "x@gmail.com", "x y@campus.edu", "", null].forEach((e) => ok(!V.isCampusEmail(e), String(e)));
  });
  test("name and otp format", () => { ok(V.isName("Rahul Sharma")); ok(!V.isName("<b>")); ok(V.isOtp("246810")); ok(!V.isOtp("12ab56")); });
  test("listing validation", () => {
    ok(V.validateListing({ title: "Book", price: "100" }).ok);
    ok(V.validateListing({ title: "Free", price: "0" }).ok);
    ok(!V.validateListing({ title: " ", price: "1" }).ok);
    ok(!V.validateListing({ title: "x", price: "-5" }).ok);
    ok(!V.validateListing({ title: "x", price: "" }).ok);
    ok(!V.validateListing({ title: "x", price: "999999" }).ok);
  });
  test("schema rejects tampered products", () => {
    ok(V.isProduct(item(1, "Book", "Textbooks", 10)));
    ok(!V.isProduct(item(1, "Book", "Textbooks", "10")));
    ok(!V.isProduct(item(1, "Book", "Textbooks", 10, { image: "javascript:alert(1)" })));
    ok(!V.isProductList("nope"));
  });
  test("otp: correct code passes once issued", () => { A.start(0); eq(A.check("246810", 1000).ok, true); });
  test("otp: wrong code counts attempts and then locks", () => {
    A.start(0);
    eq(A.check("000000", 1).left, 4);
    for (let i = 0; i < 4; i++) A.check("000000", 2);
    eq(A.check("246810", 3).reason, "locked");
  });
  test("otp: expires after 5 minutes", () => { A.start(0); eq(A.check("246810", 6 * 60 * 1000).reason, "expired"); });
  test("session: expires after 24 hours and needs verifiedAt", () => {
    const u = { email: "a@campus.edu", verified: true, verifiedAt: 0 };
    ok(A.isSessionValid(u, 1000)); ok(!A.isSessionValid(u, 25 * 3600 * 1000));
    ok(!A.isSessionValid({ email: "a@campus.edu", verified: true }, 1)); ok(!A.isSessionValid(null));
  });
  test("storage: corrupt JSON falls back", () => {
    root.localStorage.setItem("t1", "{not json"); eq(RL.storage.load("t1", "fb"), "fb");
  });
  test("storage: failed schema check falls back and clears key", () => {
    root.localStorage.setItem("t2", JSON.stringify([{ id: "x" }]));
    eq(RL.storage.load("t2", "fb", V.isProductList), "fb"); eq(root.localStorage.getItem("t2"), null);
  });
  test("storage: save reports failure instead of throwing", () => {
    const real = root.localStorage.setItem;
    root.localStorage.setItem = () => { const e = new Error("full"); e.name = "QuotaExceededError"; throw e; };
    const r = RL.storage.save("k", 1); root.localStorage.setItem = real; eq(r, { ok: false, error: "quota" });
  });
  const list = [item(1, "Scientific Calculator", "Electronics", 850), item(2, "Lab Coat", "Lab Equipment", 220),
    item(3, "Calculus Workbook", "Textbooks", 190), item(4, "Old Lamp", "Dorm Essentials", 100, { status: "Sold" })];
  test("search: hides sold items and filters category", () => {
    eq(S.rank(list).map((p) => p.id), [1, 2, 3]); eq(S.rank(list, { category: "Textbooks" }).map((p) => p.id), [3]);
  });
  test("search: ranks title matches first", () => { eq(S.rank(list, { query: "calculator" })[0].id, 1); });
  test("search: tolerates a one-letter typo", () => { eq(S.rank(list, { query: "calculater" })[0].id, 1); });
  test("search: unknown word returns nothing", () => { eq(S.rank(list, { query: "zzzzzz" }).length, 0); });
  test("search: sorts by price", () => {
    eq(S.rank(list, { sort: "low" }).map((p) => p.price), [220, 190, 850].sort((a, b) => a - b));
    eq(S.rank(list, { sort: "high" })[0].id, 1);
  });
  test("price suggestion", () => { const s = S.suggestPrice("Textbooks", "Good"); ok(s.low < s.high); eq(S.suggestPrice("x", "Good"), null); });
  test("similar items exclude self and sold", () => {
    const ids = S.similar(list[0], list).map((p) => p.id); ok(!ids.includes(1) && !ids.includes(4));
  });
  test("api: paginates results", async () => {
    const big = Array.from({ length: 20 }, (_, i) => item(i + 1, "Item " + i, "Textbooks", i));
    const p1 = await RL.api.queryListings(big, { page: 1 }), p3 = await RL.api.queryListings(big, { page: 3 });
    eq(p1.items.length, 8); eq(p1.hasMore, true); eq(p3.items.length, 20); eq(p3.hasMore, false);
  });

  Promise.all(pending).then(() => {
    RL.testResults = results;
    const failed = results.filter((r) => !r.ok);
    if (typeof document !== "undefined") {
      const out = document.getElementById("results");
      out.innerHTML = `<h2>${results.length - failed.length}/${results.length} tests passed</h2>` +
        results.map((r) => `<div class="${r.ok ? "pass" : "fail"}">${r.ok ? "PASS" : "FAIL"} - ${r.name}${r.ok ? "" : ": " + r.msg}</div>`).join("");
    } else {
      results.forEach((r) => console.log((r.ok ? "PASS " : "FAIL ") + r.name + (r.msg ? " :: " + r.msg : "")));
      console.log(`${results.length - failed.length}/${results.length} passed`);
      process.exitCode = failed.length ? 1 : 0;
    }
  });
})(typeof window !== "undefined" ? window : globalThis);
