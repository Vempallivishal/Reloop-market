/* Simulated campus sign-in: OTP expiry, attempt limit and session lifetime.
   Still client-side (demo only) - a real deployment must verify on a server. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const DEMO_OTP = "246810";
  const OTP_LIFETIME_MS = 5 * 60 * 1000;
  const SESSION_LIFETIME_MS = 24 * 60 * 60 * 1000;
  const MAX_ATTEMPTS = 5;
  let state = { issuedAt: null, tries: 0 };

  function start(now = Date.now()) {
    state = { issuedAt: now, tries: 0 };
  }

  function check(code, now = Date.now()) {
    if (state.issuedAt === null) return { ok: false, reason: "none" };
    if (now - state.issuedAt > OTP_LIFETIME_MS) return { ok: false, reason: "expired" };
    if (state.tries >= MAX_ATTEMPTS) return { ok: false, reason: "locked" };
    state.tries++;
    if (!RL.validators.isOtp(code) || String(code).trim() !== DEMO_OTP)
      return { ok: false, reason: "wrong", left: MAX_ATTEMPTS - state.tries };
    state = { issuedAt: null, tries: 0 };
    return { ok: true };
  }

  function isSessionValid(user, now = Date.now()) {
    return !!user && user.verified === true && Number.isFinite(user.verifiedAt) &&
      now - user.verifiedAt < SESSION_LIFETIME_MS && RL.validators.isCampusEmail(user.email);
  }

  RL.auth = { start, check, isSessionValid, MAX_ATTEMPTS };
})(typeof window !== "undefined" ? window : globalThis);
