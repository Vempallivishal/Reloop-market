/* Data-access seam. The UI only talks to this async API, so swapping localStorage
   for a real REST backend later means changing this file, not the UI code. */
(function (root) {
  const RL = (root.ReLoop = root.ReLoop || {});
  const PAGE_SIZE = 8;

  function queryListings(list, { query, category, sort, page = 1, pageSize = PAGE_SIZE } = {}) {
    return new Promise((resolve, reject) => {
      try {
        const all = RL.search.rank(list, { query, category, sort });
        const items = all.slice(0, page * pageSize);
        resolve({ items, total: all.length, hasMore: items.length < all.length });
      } catch (err) {
        reject(err);
      }
    });
  }

  RL.api = { queryListings, PAGE_SIZE };
})(typeof window !== "undefined" ? window : globalThis);
